# YetiPL 7.4 — Cool World Datapack

Target: Minecraft Java / Paper 26.2
Data pack format: 107.1
Custom dimension: `yetipl:cool_world`
Custom biomes: 29

## Install
Put this ZIP in the Cool World world/datapacks folder before generating the world, then restart and check `/datapack list`.

## Custom wood/leaves
Minecraft datapacks can define custom biomes/worldgen but cannot create brand-new block IDs. Maple, Flower, Redwood, Yetiwood, etc. are recorded in `COOL-WORLD-BIOMES.json` as integration hooks. YetiPL + the YetisBOXXED resource pack/custom-block system should provide the actual custom wood/leaves. The biome generation currently uses vanilla vegetation as placeholders.

## Testing
This targets Minecraft 26.2 data pack format 107.1. Test it on a staging Paper 26.2 world before live use. Worldgen files are version-sensitive.
