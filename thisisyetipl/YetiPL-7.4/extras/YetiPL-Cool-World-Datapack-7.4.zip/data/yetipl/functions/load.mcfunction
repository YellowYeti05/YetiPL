tellraw @a [{"text":"✦ YetiPL 7.4 ✦ ","color":"gold","bold":true},{"text":"Cool World datapack loaded (29 biomes).","color":"green"}]
