# YetiPL Shopkeepers — Gold Edition

Target: Minecraft Java 26.2 / Paper 26.2
Resource-pack format: 88.0

This starter resource pack gives YetiPL custom shopkeeper GUI/model assets with a
yellow, gold, and metallic-gold theme.

Included styles:
- Gold Merchant
- Miner
- Farmer
- Enchanter
- Yeti Trader
- Customize button

## How YetiPL should use it

For modern Minecraft versions, YetiPL can give a GUI item an `minecraft:item_model`
component pointing to one of these names:

- yetipl:shopkeeper_gold
- yetipl:shopkeeper_miner
- yetipl:shopkeeper_farmer
- yetipl:shopkeeper_enchanter
- yetipl:shopkeeper_yeti
- yetipl:shopkeeper_customize

The same models can be used on equipped items or item-display entities to visually
customize a shopkeeper without replacing every vanilla villager texture globally.

## Suggested YetiPL commands

/shopkeeper create <type>
/shopkeeper edit <name>
/shopkeeper style <name> <gold_merchant|miner|farmer|enchanter|yeti_trader>
/shopkeeper name <name> <display-name>
/shopkeeper glow <name> <on|off>
/shopkeeper size <name> <small|normal|large>
/shopkeeper trades <name>
/shopkeeper remove <name>

The edit command should open a gold-themed GUI with:
- Appearance
- Name
- Trades
- Profession / type
- Equipment
- Glow
- Invulnerability
- Look-at-player
- Sounds
- Teleport / location
- Delete shopkeeper

## Important

A resource pack changes visuals; YetiPL still needs plugin code to create the entity,
store shopkeeper data, handle trades, and apply the selected item models.
